import { useRef, useState } from 'react';
import { parseFile } from '../lib/csv';

export default function PartInput({ parts, onPartsChange }) {
  const [input, setInput] = useState('');
  const [inputType, setInputType] = useState('vendor');
  const [dragOver, setDragOver] = useState(false);
  const [fileName, setFileName] = useState(null);
  const fileRef = useRef(null);

  const addParts = () => {
    if (!input.trim()) return;
    const newParts = input
      .split(/[,\n;]+/)
      .map((p) => p.trim())
      .filter(Boolean)
      .map((p) =>
        inputType === 'ingram'
          ? { ingramPartNumber: p, displayNumber: p, type: 'IPN', qty: 1 }
          : { vendorPartNumber: p, displayNumber: p, type: 'VPN', qty: 1 }
      );
    onPartsChange([...parts, ...newParts]);
    setInput('');
  };

  const handleFile = async (file) => {
    if (!file) return;
    try {
      const parsed = await parseFile(file);
      if (parsed.length === 0) {
        alert('No part numbers found in file. Make sure the file has a column with "Part" in the header.');
        return;
      }
      setFileName(file.name);
      onPartsChange([...parts, ...parsed]);
    } catch (err) {
      alert(`Error reading file: ${err.message}`);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) handleFile(file);
  };

  const removePart = (idx) => onPartsChange(parts.filter((_, i) => i !== idx));
  const clearAll = () => {
    onPartsChange([]);
    setFileName(null);
  };

  const updateQty = (idx, newQty) => {
    const updated = [...parts];
    updated[idx] = { ...updated[idx], qty: Math.max(1, parseInt(newQty) || 1) };
    onPartsChange(updated);
  };

  const totalQty = parts.reduce((sum, p) => sum + (p.qty || 1), 0);

  return (
    <div className="card" style={{ animation: 'fadeIn 0.3s ease' }}>
      {/* Header */}
      <div className="card-header">
        <h2 className="card-title">Part Numbers</h2>
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          <span className="count-badge">{parts.length} items</span>
          {totalQty > parts.length && (
            <span className="count-badge qty-badge">{totalQty} total qty</span>
          )}
        </div>
      </div>

      {/* File upload zone — prominent */}
      <div
        className={`drop-zone ${dragOver ? 'drag-over' : ''}`}
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
        onClick={() => fileRef.current?.click()}
      >
        <div className="drop-icon">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
            <polyline points="17 8 12 3 7 8" />
            <line x1="12" y1="3" x2="12" y2="15" />
          </svg>
        </div>
        <div className="drop-text">
          <strong>Drop a customer worksheet here</strong>
          <span>.xlsx, .xls, .csv — auto-detects part numbers & quantities</span>
        </div>
        {fileName && (
          <div className="file-badge">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>
            {fileName}
          </div>
        )}
        <input
          ref={fileRef}
          type="file"
          accept=".xlsx,.xls,.xlsm,.csv,.txt,.tsv"
          onChange={(e) => handleFile(e.target.files?.[0])}
          style={{ display: 'none' }}
        />
      </div>

      {/* Divider */}
      <div className="or-divider">
        <span>or enter manually</span>
      </div>

      {/* Manual input */}
      <div style={{ display: 'flex', gap: '8px', alignItems: 'center', marginBottom: '10px' }}>
        <div className="toggle-group">
          <button
            className={`toggle-btn ${inputType === 'vendor' ? 'active' : ''}`}
            onClick={() => setInputType('vendor')}
          >
            Vendor / Mfg P/N
          </button>
          <button
            className={`toggle-btn ${inputType === 'ingram' ? 'active' : ''}`}
            onClick={() => setInputType('ingram')}
          >
            Ingram P/N
          </button>
        </div>
      </div>

      <div style={{ display: 'flex', gap: '8px', alignItems: 'flex-start' }}>
        <textarea
          className="text-input mono"
          placeholder={'Enter part numbers separated by commas, semicolons, or new lines\ne.g. DM-NVX-360, SRT3000RMXLT-NCUS, AP9571A'}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              addParts();
            }
          }}
          rows={2}
          style={{ flex: 1, resize: 'vertical' }}
        />
        <button className="btn-add" onClick={addParts}>+ Add</button>
      </div>

      {/* Parts list — table format for better readability with qty */}
      {parts.length > 0 && (
        <div className="parts-list">
          <table className="parts-table">
            <thead>
              <tr>
                <th style={{ width: '50px' }}>Type</th>
                <th>Part Number</th>
                <th style={{ width: '100px' }}>Description</th>
                <th style={{ width: '70px', textAlign: 'center' }}>Qty</th>
                <th style={{ width: '36px' }}></th>
              </tr>
            </thead>
            <tbody>
              {parts.map((p, i) => (
                <tr key={i}>
                  <td><span className="chip-type">{p.type}</span></td>
                  <td className="mono" style={{ fontWeight: 500, color: 'var(--text-primary)' }}>
                    {p.displayNumber}
                  </td>
                  <td style={{ fontSize: '11px', color: 'var(--text-muted)', maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {p.description || '—'}
                  </td>
                  <td style={{ textAlign: 'center' }}>
                    <input
                      className="qty-input"
                      type="number"
                      min="1"
                      value={p.qty || 1}
                      onChange={(e) => updateQty(i, e.target.value)}
                    />
                  </td>
                  <td>
                    <button className="btn-remove" onClick={() => removePart(i)} title="Remove">×</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Actions */}
      {parts.length > 0 && (
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '8px' }}>
          <button className="btn-ghost" onClick={clearAll}>Clear all</button>
        </div>
      )}

      <style>{`
        .card {
          background: var(--surface);
          border-radius: var(--radius);
          border: 1px solid var(--border);
          padding: 24px;
        }
        .card-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 16px;
        }
        .card-title {
          font-size: 15px;
          font-weight: 700;
          color: var(--text-primary);
          letter-spacing: -0.2px;
        }
        .count-badge {
          font-size: 12px;
          font-weight: 700;
          padding: 2px 10px;
          border-radius: 20px;
          background: var(--surface-3);
          color: var(--text-muted);
          font-family: var(--font-mono);
        }
        .qty-badge {
          background: var(--accent-soft);
          color: var(--accent);
        }

        /* Drop zone */
        .drop-zone {
          padding: 24px;
          border: 2px dashed var(--border);
          border-radius: var(--radius);
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          gap: 8px;
          cursor: pointer;
          transition: all var(--transition);
          text-align: center;
        }
        .drop-zone:hover, .drop-zone.drag-over {
          border-color: var(--accent);
          background: var(--accent-soft);
        }
        .drop-icon {
          color: var(--text-muted);
          transition: color var(--transition);
        }
        .drop-zone:hover .drop-icon { color: var(--accent); }
        .drop-text {
          display: flex;
          flex-direction: column;
          gap: 2px;
        }
        .drop-text strong {
          color: var(--text-secondary);
          font-size: 13px;
        }
        .drop-text span {
          color: var(--text-muted);
          font-size: 11px;
        }
        .file-badge {
          display: flex;
          align-items: center;
          gap: 5px;
          margin-top: 4px;
          padding: 3px 10px;
          border-radius: 10px;
          background: var(--green-soft);
          color: var(--green);
          font-size: 11px;
          font-weight: 600;
          font-family: var(--font-mono);
        }

        /* Divider */
        .or-divider {
          display: flex;
          align-items: center;
          gap: 12px;
          margin: 16px 0;
          color: var(--text-muted);
          font-size: 11px;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          font-weight: 600;
        }
        .or-divider::before, .or-divider::after {
          content: '';
          flex: 1;
          height: 1px;
          background: var(--border);
        }

        /* Toggle */
        .toggle-group {
          display: flex;
          background: var(--surface-2);
          border-radius: var(--radius-sm);
          padding: 3px;
          border: 1px solid var(--border);
        }
        .toggle-btn {
          padding: 6px 14px;
          border-radius: 4px;
          font-size: 12px;
          font-weight: 600;
          color: var(--text-muted);
          background: transparent;
        }
        .toggle-btn.active {
          background: var(--accent);
          color: #fff;
        }

        /* Text input */
        .text-input {
          background: var(--surface-2);
          border: 1px solid var(--border);
          border-radius: var(--radius-sm);
          padding: 10px 12px;
          font-size: 13px;
          color: var(--text-primary);
          line-height: 1.5;
          transition: border-color var(--transition), box-shadow var(--transition);
          width: 100%;
        }
        .text-input.mono, .mono {
          font-family: var(--font-mono);
          font-size: 12px;
        }
        .btn-add {
          padding: 10px 20px;
          background: var(--surface-3);
          border: 1px solid var(--border);
          border-radius: var(--radius-sm);
          color: var(--text-primary);
          font-weight: 600;
          font-size: 13px;
          white-space: nowrap;
          align-self: stretch;
        }
        .btn-add:hover {
          background: var(--surface-hover);
          border-color: var(--border-light);
        }

        /* Parts table */
        .parts-list {
          margin-top: 14px;
          max-height: 280px;
          overflow-y: auto;
          border: 1px solid var(--border);
          border-radius: var(--radius-sm);
        }
        .parts-table {
          width: 100%;
          font-size: 12px;
        }
        .parts-table thead th {
          padding: 7px 10px;
          text-align: left;
          font-size: 10px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.06em;
          color: var(--text-muted);
          background: var(--surface-2);
          border-bottom: 1px solid var(--border);
          position: sticky;
          top: 0;
        }
        .parts-table tbody td {
          padding: 6px 10px;
          border-bottom: 1px solid rgba(40,45,62,0.4);
          vertical-align: middle;
        }
        .parts-table tbody tr:hover {
          background: rgba(59,130,246,0.03);
        }
        .chip-type {
          font-size: 9px;
          font-weight: 800;
          font-family: var(--font-mono);
          color: var(--accent);
          letter-spacing: 0.05em;
          padding: 2px 5px;
          border-radius: 3px;
          background: var(--accent-soft);
        }
        .qty-input {
          width: 50px;
          padding: 4px 6px;
          text-align: center;
          background: var(--surface-2);
          border: 1px solid var(--border);
          border-radius: 4px;
          color: var(--text-primary);
          font-family: var(--font-mono);
          font-size: 12px;
          font-weight: 600;
        }
        .qty-input:focus {
          border-color: var(--accent) !important;
          box-shadow: 0 0 0 2px var(--accent-soft);
        }
        .btn-remove {
          width: 24px;
          height: 24px;
          border-radius: 4px;
          display: flex;
          align-items: center;
          justify-content: center;
          color: var(--text-muted);
          font-size: 16px;
          line-height: 1;
        }
        .btn-remove:hover {
          background: rgba(239,68,68,0.1);
          color: var(--red);
        }
        .btn-ghost {
          padding: 6px 12px;
          color: var(--text-muted);
          font-size: 12px;
          font-weight: 500;
          text-decoration: underline;
          text-underline-offset: 2px;
        }
        .btn-ghost:hover { color: var(--text-secondary); }
      `}</style>
    </div>
  );
}
